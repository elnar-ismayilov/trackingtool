package com.hrs.trackingtool.modelvalue;

// parcel types like letter, packages
public enum ParcelType {
    LETTER,PACKAGE
}
