package com.hrs.trackingtool;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TrackingtoolApplication.class)
public class TrackingtoolApplicationTests {

	@Test
	public void contextLoads() {
	}

}

